function y = sample2sec(sample_rate,sample_known)

y = (1000 .* sample_known)./sample_rate
